<?php
shell_exec("sudo reboot");
?>