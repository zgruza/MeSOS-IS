rm -- "$0"
reboot