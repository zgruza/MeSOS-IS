chmod -R 777 /var/www/html
rm -- "$0"
reboot